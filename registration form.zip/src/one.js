function off(){
  document.getElementById('img').src='https://www.collinsdictionary.com/images/full/lightbulb_111547856_1000.jpg';
}
function on(){
  document.getElementById('img').src='https://img.freepik.com/free-vector/realistic-light-bulb-with-electricity_23-2149129410.jpg?w=2000';
}